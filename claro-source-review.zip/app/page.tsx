"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export default function ClaroLandingPage() {
  const [open, setOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const target = document.getElementById(id);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setOpen(false);
  };

  return (
    <div
      className="min-h-screen bg-[#f5f1ea] text-neutral-900 overflow-x-hidden"
      style={{
        scrollBehavior: "smooth",
        fontFamily: '"Playfair Display", Georgia, serif',
      }}
    >
      <header className="fixed top-0 left-0 w-full z-50 backdrop-blur-xl bg-[#f5f1ea]/80 border-b border-black/5 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-5 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <svg width="42" height="42" viewBox="0 0 42 42" className="opacity-80">
              <path d="M32 9 C26 4, 13 7, 10 20 C8 31, 18 38, 30 32" stroke="currentColor" strokeWidth="0.9" fill="none" strokeLinecap="round" />
            </svg>
            <div className="text-2xl tracking-[0.35em] font-bold">CLARO</div>
            <span className="hidden md:block text-xs tracking-[0.25em] uppercase text-neutral-500 ml-2">
              Where direction becomes clear
            </span>
          </div>

          <button onClick={() => setOpen(!open)} className="relative flex items-center justify-center w-14 h-14 group" aria-label="Menu">
            <motion.svg
              animate={{ rotate: [0, 6, -6, 0], scale: [1, 1.05, 1], x: [0, 3, -3, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              className="absolute w-14 h-14 opacity-40"
              viewBox="0 0 48 48"
            >
              <path d="M24 4 C35 6, 43 14, 42 24 C42 34, 35 42, 24 44 C14 43, 6 35, 5 24 C5 14, 13 6, 24 4" stroke="currentColor" strokeWidth="1" fill="none" strokeLinecap="round" />
            </motion.svg>
            <div className="flex flex-col gap-1">
              <span className="w-8 h-[1px] bg-black block transition-all group-hover:w-6" />
              <span className="w-6 h-[1px] bg-black block transition-all group-hover:w-8" />
            </div>
          </button>
        </div>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.45 }}
              className="absolute top-full right-4 md:right-6 bg-white/95 backdrop-blur-xl shadow-2xl rounded-3xl overflow-hidden py-6 md:py-8 px-8 md:px-10"
            >
              <nav className="flex flex-col gap-5 text-lg tracking-wide">
                <button onClick={() => scrollToSection("home")} className="text-left">Home</button>
                <button onClick={() => scrollToSection("wie-title")} className="text-left">Wie zijn wij</button>
                <button onClick={() => scrollToSection("doen")} className="text-left">Wat doen wij</button>
                <button onClick={() => scrollToSection("contact")} className="text-left">Contact</button>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main>
        <section id="home" className="min-h-screen flex items-center justify-center px-6 relative overflow-hidden bg-[#f7f3ed]">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1.4 }} className="absolute inset-0 opacity-20">
            <motion.div animate={{ y: [0, -30, 0] }} transition={{ repeat: Infinity, duration: 6.5 }} className="absolute top-1/3 left-[-10%] w-[500px] h-[500px]">
              <svg viewBox="0 0 500 500" className="w-full h-full">
                <path d="M250 20 C420 30, 470 180, 455 260 C430 410, 290 470, 180 450 C70 420, 20 300, 35 180 C55 70, 150 10, 250 20" stroke="currentColor" strokeWidth="1" fill="none" opacity="0.5" />
              </svg>
            </motion.div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.2 }} className="relative text-center max-w-6xl">
            <div className="mb-6 flex flex-col items-center gap-5 relative">
              <svg width="110" height="110" viewBox="0 0 110 110" className="opacity-80">
                <path d="M80 24 C61 10, 29 20, 24 51 C22 77, 47 91, 74 79" stroke="currentColor" strokeWidth="1" fill="none" strokeLinecap="round" />
              </svg>
              <div className="text-3xl md:text-6xl tracking-[0.35em] font-bold">CLARO</div>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-[7.5rem] tracking-tight leading-[0.95]">
              <span className="block">Waar richting</span>
              <span className="block md:ml-24">helder wordt</span>
            </h1>

            <p className="text-neutral-500 italic text-lg md:text-xl mb-6 leading-[1.4]">Where direction becomes clear</p>
            <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 3 }}>
              <button onClick={() => scrollToSection("contact")} className="inline-block border border-black/20 px-8 py-3 rounded-full text-sm tracking-[0.25em] uppercase">
                Contact opnemen
              </button>
            </motion.div>
          </motion.div>
        </section>

        <section className="max-w-4xl mx-auto px-6 md:px-10 py-12 md:py-20 text-left leading-[1.8] text-[1.05rem] text-neutral-700">
  <p className="mb-6">
  Claro Balance is een praktijk voor coaching en persoonlijke begeleiding in Hasselt en Limburg, voor mensen die op zoek zijn naar meer helderheid, richting en balans.
</p>

<p>
    Wanneer praten niet meer volstaat.<br />
    Wanneer het niet meer stroomt.<br />
    Wanneer je voelt dat er iets wringt, maar niet precies weet wat of hoe je het moet aanpakken.
  </p>

  <p className="mt-6">
    Bij Claro Balance bieden we coaching en persoonlijke begeleiding in Hasselt en Limburg voor mensen die op zoek zijn naar meer helderheid, richting en evenwicht in hun leven.
  </p>

  <p className="mt-6">
    We ondersteunen bij levensvragen, persoonlijke groei, stress, burn-out, relatieproblemen en belangrijke keuzes, zowel privé als professioneel.
  </p>

  <p className="mt-6">
    Bij Claro creëren we ruimte om stil te staan. Om helder te kijken naar wat speelt.
  </p>

   <p className="mt-6">
    Om eerlijk te benoemen wat vastzit. En om bewust te kiezen hoe het verder mag.
  </p>

  <p className="mt-6">
    Met aandacht, diepgang en respect voor ieders tempo.
  </p>
</section>

<div className="max-w-4xl mx-auto px-6 md:px-10">
  <h2
  id="doen"
  className="text-4xl md:text-5xl tracking-[0.3em] font-bold text-neutral-900 mb-10 scroll-mt-28"
    style={{ fontFamily: '"Playfair Display", Georgia, serif' }}
  >
    WAT DOEN WIJ
  </h2>

<p className="max-w-3xl text-lg leading-[1.75] text-neutral-600 mb-10">
  Claro Balance biedt <a href="/coaching-hasselt">coaching</a> en persoonlijke begeleiding aan mensen in Hasselt en Limburg die vastlopen in hun persoonlijke leven, relaties, gezin of professionele context. We begeleiden onder meer bij stress, burn-out, persoonlijke groei, levensvragen, relationele uitdagingen en belangrijke keuzes.
</p>

  <div className="max-w-3xl leading-[1.75] text-neutral-700 space-y-6">
    <p>
      Claro is ontstaan vanuit een gedeelde overtuiging: dat echte begeleiding vraagt om betrokkenheid, helderheid en respect.
    </p>

    <p>
      Claro Balance biedt coaching, persoonlijke begeleiding en ondersteuning aan mensen die vastlopen in hun persoonlijke leven, <a href="/relatiebegeleiding-hasselt">relaties</a>, gezin of professionele context.
    </p>

    <p>
      Onze achtergronden zijn verschillend, maar vullen elkaar aan.
    </p>

    <p>
      Ils ondersteunt bij persoonlijke groei, beslissingen nemen, balans en levensvragen, zowel privé als binnen werk- en <a href="/ouder-en-gezinsbegeleiding-hasselt">gezinscontext</a>.
    </p>

    <p>
      Karl helpt bij het maken van keuzes en het omgaan met uitdagingen in je persoonlijke, professionele of relationele leven.
    </p>
  </div>
</div>
        <section className="max-w-4xl mx-auto px-6 md:px-10 py-16 md:py-20">
          <h2
            className="text-3xl md:text-4xl tracking-[0.2em] font-bold text-neutral-900 mb-10"
            style={{ fontFamily: '"Playfair Display", Georgia, serif' }}
          >
            VEELGESTELDE VRAGEN
          </h2>

          <div className="max-w-3xl space-y-8 text-neutral-700 leading-[1.75]">
            <div>
              <h3 className="text-xl font-semibold text-neutral-900 mb-2">
                Wat doet Claro Balance?
              </h3>
              <p>
                Claro Balance biedt coaching en persoonlijke begeleiding in Hasselt
                en Limburg. We begeleiden mensen bij persoonlijke groei, levensvragen,
                stress, <a href="/burn-out-begeleiding-limburg">burn-out</a>, relaties, gezin en belangrijke keuzes.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-neutral-900 mb-2">
                Voor wie is coaching bij Claro Balance?
              </h3>
              <p>
                Claro Balance is er voor mensen die meer helderheid, richting en
                balans zoeken in hun persoonlijke, relationele of professionele leven.
                We begeleiden zowel individuen als koppels en gezinnen.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-neutral-900 mb-2">
                Waarvoor kan ik bij Claro Balance terecht?
              </h3>
              <p>
                Je kunt bij Claro Balance terecht met vragen rond persoonlijke groei,
                stress, burn-out, relaties, gezin, levenskeuzes en andere situaties
                waarin je vastloopt of opnieuw richting wilt vinden.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-neutral-900 mb-2">
                Waar is Claro Balance gevestigd?
              </h3>
              <p>
                Claro Balance is gevestigd in Hasselt en biedt persoonlijke begeleiding
                aan mensen uit Hasselt en de ruimere regio Limburg.
              </p>
            </div>
          </div>
        </section>

        <section id="wie" className="bg-white py-20 md:py-28
         px-6 relative overflow-hidden">
          <div className="scroll-mt-32 absolute -top-32" id="wie-anchor" />
          <div className="max-w-5xl mx-auto mb-16 relative z-10">
            <h2 id="wie-title" className="text-4xl md:text-5xl tracking-[0.3em] font-bold text-neutral-900 scroll-mt-24" style={{ fontFamily: '"Playfair Display", Georgia, serif' }}>
              WIE ZIJN WIJ
            </h2>
          </div>
        
          <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-24 items-start md:items-stretch relative z-10">
            <div className="flex flex-col">
              <motion.img
                initial={{ opacity: 0, y: 40, scale: 1.03 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 1.2, ease: "easeOut" }}
                src="/Karl2.jpg"
                alt="Karl Ketelslagers"
                className="h-[420px] md:h-[560px] w-full object-cover object-center rounded-2xl mb-8 grayscale contrast-110 brightness-95 sepia-[0.15] shadow-2xl bg-neutral-200"
              />
              <h2 className="text-4xl font-bold mb-6">Karl Ketelslagers</h2>
              <p className="text-lg leading-[1.75] space-y-5 text-neutral-700">Karl begeleidt mensen die vastlopen bij belangrijke keuzes, stress, relationele uitdagingen of veranderingen in hun persoonlijke en professionele leven.</p>
              <p>Vanuit zijn ervaring als ondernemer begrijpt hij de impact van verantwoordelijkheid, druk, leiderschap en complexe beslissingen.</p>
              <p>Hij helpt mensen om opnieuw overzicht te krijgen, richting te bepalen en concrete stappen te zetten die echt bij hen passen.</p>
              <p>Zijn begeleiding richt zich onder meer op persoonlijke ontwikkeling, coaching, burn-outpreventie, relationele vraagstukken en professionele uitdagingen.</p>
            </div>

            <div className="flex flex-col">
              <motion.img
                initial={{ opacity: 0, y: 40, scale: 1.03 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 1.4, ease: "easeOut" }}
                src="Ils2.jpg"
                alt="Ils Camps"
                className="h-[420px] md:h-[560px] w-full object-cover object-center rounded-2xl mb-8 grayscale contrast-110 brightness-95 sepia-[0.15] shadow-2xl bg-neutral-200"
              />
              <h2 className="text-4xl font-bold mb-6">Ils Camps</h2>
              <p className="text-lg leading-[1.75] space-y-5 text-neutral-700">Ils ondersteunt mensen, koppels en gezinnen bij persoonlijke groei, emotioneel welzijn, balans en levensvragen.</p>
              <p>Ils heeft ruime ervaring in het buitengewoon onderwijs en een brede pedagogische achtergrond. Ze heeft bijzondere expertise in autismespectrumstoornissen (ASS), gedrag en emotionele ontwikkeling.</p>
              <p>Ze begeleidt mensen die worstelen met stress, onzekerheid, relationele uitdagingen of moeilijke levensfasen.</p>
              <p>Met zachtheid, aandacht en oprechte betrokkenheid helpt ze mensen opnieuw verbinding te maken met zichzelf, hun gevoelens en hun noden.</p>
            </div>
          </div>
        </section>

<section className="bg-[#f5f1ea] py-16 md:py-24 px-6">
  <div className="max-w-4xl mx-auto">
    <h2
      className="text-3xl md:text-4xl tracking-[0.2em] font-bold text-neutral-900 mb-8"
      style={{ fontFamily: '"Playfair Display", Georgia, serif' }}
    >
      BEGELEIDING MET OOG VOOR HET GEHEEL
    </h2>

    <div className="max-w-3xl space-y-5 text-lg leading-[1.75] text-neutral-700">
      <p>
        Soms helpt het om vanuit verschillende expertises naar een vraag te kijken.
        Claro werkt vanuit Huis39 in Hasselt, een praktijkomgeving waar professionals
        elk vanuit hun eigen expertise mensen begeleiden.
      </p>
      <p>
        Wanneer een vraag om bijkomende expertise vraagt, kunnen we bekijken welke
        verdere begeleiding passend kan zijn.
      </p>
      <p>
        Zo houden we oog voor de persoon achter de hulpvraag en voor wat op dat
        moment echt kan helpen.
      </p>
    </div>
  </div>
</section>

        <section id="contact" className="bg-neutral-950 text-white py-16 md:py-24 px-6 relative overflow-hidden scroll-mt-28">
          <div className="max-w-5xl mx-auto mb-16 relative z-10">
            <h2 className="text-4xl md:text-5xl tracking-[0.3em] font-bold text-white" style={{ fontFamily: '"Playfair Display", Georgia, serif' }}>
              CONTACT
            </h2>
          </div>

          <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-16">
            <div className="space-y-4 text-lg leading-[1.08] text-neutral-300">
              <p>Claro Balance is gevestigd in Hasselt</p>
              <p>info@clarobalance.com</p>
              <p>0495/224924 - 0473/278769</p>
              <p>Weggevoerdenstraat 39, 3500 Hasselt</p>
            </div>

            <form
  action="https://formspree.io/f/mdaypvgy"
  method="POST"
  className="space-y-6"
>
  <input
    type="text"
    name="name"
    placeholder="Naam"
    required
    className="w-full p-4 rounded-xl bg-white/10 backdrop-blur text-white placeholder-white/60"
  />
  <input
    type="email"
    name="email"
    placeholder="Email"
    required
    className="w-full p-4 rounded-xl bg-white/10 backdrop-blur text-white placeholder-white/60"
  />
  <textarea
    name="message"
    placeholder="Bericht"
    rows={5}
    required
    className="w-full p-4 rounded-xl bg-white/10 backdrop-blur text-white placeholder-white/60"
  />
  <button
    type="submit"
    className="w-full bg-white text-black py-4 rounded-xl font-semibold hover:opacity-90 transition"
  >
    Verstuur
  </button>
</form>
          </div>
        </section>
      </main>
    </div>
  );
}
